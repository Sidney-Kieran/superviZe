/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package COT.SuperviZe;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author CARTER
 */
public class DBConnect {
    
    Connection c = null;
    Statement stmt = null;
    
    //this fuction creates a connection to the database and returns the status of the connection
  public Connection DBconn(){
    try {
    Class.forName("org.sqlite.JDBC");
  
    
    /*
      creates the connection to the database and creates the database if it doesn't exists and stores the 
      status of the connection into a variable "c"
    */
    c = DriverManager.getConnection("jdbc:sqlite:supervize.sqlite");
    
    } catch ( ClassNotFoundException | SQLException e ) {
        System.err.println( e.getClass().getName() + ": " + e.getMessage() );
        System.exit(0);
    }
        System.out.println("Opened database successfully");
        return c;
    }
  
  //this method checks if the required tables exists and if they are not, it creates them
  public void createTables(){
      Connection con = this.DBconn();
      String sql;
        try {
            stmt = con.createStatement();
            sql = "CREATE TABLE if not exists Lecturer" +
            "( LecID	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,"+
            "Lsurname	TEXT NOT NULL,"+
            "Lname	TEXT NOT NULL,"+
            "Username   TEXT NOT NULL,"+
            "Ltitle	TEXT NOT NULL,"+
            "Lpassword	TEXT NOT NULL,"+
            "Active	INTERGER NOT NULL"+
            ");";
            stmt.executeUpdate(sql);
            stmt.close(); 
        
          stmt = con.createStatement();
          sql = "CREATE TABLE if not exists Topic"+
                 "(TopicID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,"+
                 "TopTitle TEXT NOT NULL UNIQUE,"+
                 "TopDescription TEXT NOT NULL,"+
                 "LecID INTEGER NOT NULL"+
                 ");";
          stmt.executeUpdate(sql);
            stmt.close();
      
          stmt = con.createStatement();
            sql = "CREATE TABLE if not exists Alert"+ 
            "(AlertID	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,"+
            "SessionID	INTEGER NOT NULL,"+
            "FOREIGN KEY(SessionID) REFERENCES Session"+
            ");";
            stmt.executeUpdate(sql);
            stmt.close();
      
      
      
          stmt = con.createStatement();
            sql = "CREATE TABLE if not exists Year"+
            "(year	TEXT NOT NULL UNIQUE,"+
            "lecID	INTEGER NOT NULL,"+
            "PRIMARY KEY(year),"+
            "FOREIGN KEY(lecID) REFERENCES Lecturer"+
            ");";
            stmt.executeUpdate(sql);
            stmt.close();
      
         stmt = con.createStatement();
             sql = "CREATE TABLE if not exists Student"+
            "( StudID	TEXT NOT NULL UNIQUE,"+
            "Sname	TEXT NOT NULL,"+
            "LecID	INTEGER NOT NULL,"+
            "TopicID	INTEGER,"+
            "year	TEXT NOT NULL,"+
            "PRIMARY KEY(StudID),"+
            "FOREIGN KEY(LecID) REFERENCES Lecturer,"+
            "FOREIGN KEY(TopicID) REFERENCES Topic,"+
            "FOREIGN KEY(year) REFERENCES Year"+
            ");";
            stmt.executeUpdate(sql);
            stmt.close(); 
     
      
      
          stmt = con.createStatement();
            sql = "CREATE TABLE if not exists Session"+
            "(SessionID	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,"+
            "SessionTime	TEXT NOT NULL,"+
            "SessionWork	TEXT NOT NULL,"+
            "SessionMarks	INTEGER,"+
            "SessionDuration	INTEGER NOT NULL,"+
            "SessionAttendance	INTEGER,"+
            "StudID	TEXT NOT NULL,"+
            "TopicID	INTEGER NOT NULL,"+
            "LecID	INTEGER NOT NULL,"+
            "FOREIGN KEY(StudID) REFERENCES Student,"+
            "FOREIGN KEY(TopicID) REFERENCES Topic,"+
            "FOREIGN KEY(LecID) REFERENCES Lecturer"+
            ");";
            stmt.executeUpdate(sql);
            stmt.close();
      }catch (SQLException e){
          System.err.println( e.getClass().getName() + ": " + e.getMessage() );
         System.exit(0);
      }
      System.out.println("Tables created successfully");
      
      
  }
}
