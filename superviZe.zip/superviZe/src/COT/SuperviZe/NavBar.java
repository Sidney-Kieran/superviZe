/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package COT.SuperviZe;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 *
 * @author CARTER
 */
public class NavBar {
    
    
    public static MenuBar topMenu(){
        
        MenuBar menuBar = new MenuBar();
        Menu student = new Menu("Student");
        MenuItem createStudent = new MenuItem("Create New Student");
        createStudent.setOnAction(e -> NewStudent.addStudent());
        student.getItems().add(createStudent);
        MenuItem listStudents = new MenuItem("List of Students");
        student.getItems().add(listStudents);
        
        Menu schedule = new Menu("Schedule");
        MenuItem createSession = new MenuItem("Create Session");
        createSession.setOnAction(e -> NewSession.createSession());
        schedule.getItems().add(createSession);
        schedule.getItems().add(new SeparatorMenuItem());
        MenuItem viewSchedule = new MenuItem("View Schedule");
        schedule.getItems().add(viewSchedule);
        
        Menu project = new Menu("Projects");
        MenuItem createProject = new MenuItem("Create New Project");
        createProject.setOnAction(e -> NewTopic.createTopic());
        project.getItems().add(createProject);
        MenuItem projectList = new MenuItem("List of Projects");
        
        Menu year = new Menu("Year");
        MenuItem createYear = new MenuItem("Create New Year");
        createYear.setOnAction(e -> NewYear.createYear());
        year.getItems().add(createYear);
        
        
        Menu report = new Menu("Report");
        MenuItem attendaceReport = new MenuItem("Attendace Report");
        MenuItem progressReport = new MenuItem("Progress Report");
        report.getItems().addAll(attendaceReport, progressReport);
        
        Menu alert = new Menu("Alert");
        ToggleGroup tGroup = new ToggleGroup();
        RadioMenuItem turnOffAlertItem = RadioMenuItemBuilder.create()
        .toggleGroup(tGroup)
        .text("Turn Off Alert")
        .build();
        RadioMenuItem turnOnAlertItem = RadioMenuItemBuilder.create()
        .toggleGroup(tGroup)
        .text("Turn On Alert")
        .selected(true)
        .build();
        alert.getItems().add(turnOffAlertItem);
        alert.getItems().add(turnOnAlertItem);
        alert.getItems().add(new SeparatorMenuItem());
        Menu ChangeSound = new Menu("Change Alert Sound");
        ChangeSound.getItems().add(new MenuItem("Choose new Sound"));
        ChangeSound.getItems().add(new MenuItem("Choose from file"));
        alert.getItems().add(ChangeSound);
        
        
        Menu help = new Menu("Help");
        MenuItem howToUse = new MenuItem("Help   F1");
        help.getItems().add(howToUse);
        help.getItems().add(new SeparatorMenuItem());
        MenuItem about = new MenuItem("About");
        help.getItems().add(about);
        menuBar.getMenus().addAll(year, student, project, schedule, report, alert, help);
        
       
        
        
        return menuBar;
        
    }
    public static void returnHome(Stage window, Scene scene){
        window.setScene(scene);
    }
}
