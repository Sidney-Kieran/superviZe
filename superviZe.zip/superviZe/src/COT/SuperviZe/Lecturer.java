/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package COT.SuperviZe;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author CARTER
 */
public class Lecturer {
   private String Name;
   private String Surname;
   private final int LectID;
   private String title;
   private String password;
   DBConnect conn = new DBConnect();
    

    public Lecturer(String Name, String Surname, int LectID) {
        this.Name = Name;
        this.Surname = Surname;
        this.LectID = LectID;
    }
public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getSurname() {
        return Surname;
    }

    public void setSurname(String Surname) {
        this.Surname = Surname;
    }

    public int getLectID() {
        return LectID;
    }
   
    public void createYear(String year){
        Connection c = conn.DBconn();
       try {
           String sql = "SELECT * FROM Year WHERE year = ?;";
           PreparedStatement prep = c.prepareStatement(sql);
           prep.setString(1, year);
           ResultSet rs = prep.executeQuery();
           if(rs.next()){
               Boxes.alert("Duplicate Error", "The Year"+ " "+year+ " " + "already exist");
               rs.close();
               prep.close();
           }else{
              sql = "INSERT INTO Year(year, lecID) VALUES(?, ?);";
              PreparedStatement prep2 = c.prepareStatement(sql);
              prep2.setString(1, year);
              prep2.setInt(2, this.LectID);
              prep2.execute();
              System.out.println("Year"+ " "+ year + " " + "created");
           }
       } catch (SQLException e) {
           System.err.println( e.getClass().getName() + ": " + e.getMessage() );
           System.exit(0);
       }
       
    }
    
    public void createTopic(String topicTitle, String topDescription){
        Connection c = conn.DBconn();
       try {
           String sql = "SELECT * FROM Topic WHERE TopTitle = ?;";
           PreparedStatement prep = c.prepareStatement(sql);
           prep.setString(1, topicTitle);
           ResultSet rs = prep.executeQuery();
           if(rs.next()){
               Boxes.alert("Duplicate Error", "The Project with name"+ " "+topicTitle+ " " + "already exist");
               rs.close();
               prep.close();
           }else{
              sql = "INSERT INTO Topic(TopTitle, TopDescription, lecID) VALUES(?, ?, ?);";
              PreparedStatement prep2 = c.prepareStatement(sql);
              prep2.setString(1, topicTitle);
              prep2.setString(2, topDescription);
              prep2.setInt(3, this.LectID);
              prep2.execute();
              System.out.println("Topic"+ " "+ topicTitle + " " + "created successfull");
           }
        }catch(SQLException e){
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
    }
    
    public void addStudent(String studID, String name, String email, String number, Year year, Topic topic){
        Connection c = conn.DBconn();
       try {
           String sql = "SELECT * FROM Student WHERE StudID = ?;";
           PreparedStatement prep = c.prepareStatement(sql);
           prep.setString(1, studID);
           ResultSet rs = prep.executeQuery();
           if(rs.next()){
               Boxes.alert("Duplicate Error", "Student with matricule "+ " "+studID+ " " + "already exist");
               rs.close();
               prep.close();
           }else{
              sql = "INSERT INTO Student(StudID, Sname, LecID, TopicID, year, StudContact, StudEmail) VALUES(?, ?, ?, ?, ?, ?, ?);";
              PreparedStatement prep2 = c.prepareStatement(sql);
              prep2.setString(1, studID);
              prep2.setString(2, name);
              prep2.setInt(3, this.LectID);
              prep2.setInt(4, topic.getTopicID());
              prep2.setString(5, year.getYear());
              prep2.setString(6, number);
              prep2.setString(7, email);
              prep2.execute();
              System.out.println("Student"+ " "+ name + " " + "created successfull");
              c.close();
           }
        }catch(SQLException e){
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
    }
    
    public void assignTopic(Student student, Topic topic){
        Connection c = conn.DBconn();
        try{
            Statement stmt = c.createStatement();
            String sql = "INSERT INTO Student(topicID)"+
                        "VALUES("+ topic.getTopicID() + ")"+
                        "WHERE( studID == " + student.getStudID() + ");";
            stmt.executeUpdate(sql);
        }catch(SQLException e){
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
    }
    
    public void createSession(Student student, String time, String date, String duration, String work, String venue){
        Connection c = conn.DBconn();
        try{
           String sql = "SELECT * FROM Session WHERE SessionTime = ? AND SessionDate = ?;";
           PreparedStatement prep = c.prepareStatement(sql);
           prep.setString(1, time);
           prep.setString(2, date);
           ResultSet rs = prep.executeQuery();
           if(rs.next()){
               Boxes.alert("Duplicate Error", "Session on "+ " "+date+ " at "+time+" already exist!" );
               rs.close();
               prep.close();
           }else{
            sql = "INSERT INTO Session(SessionTime, SessionDate, SessionWork, SessionMarks, SessionDuration,SessionAttendance, LecID, StudID, TopicID, Sessionvenue)"+
                        "VALUES(?,?,?,?,?,?,?,?,?,?);";
            prep = c.prepareStatement(sql);
            prep.setString(1, time);
            prep.setString(2, date);
            prep.setString(3, work);
            prep.setInt(4, 0);
            prep.setString(5, duration);
            prep.setInt(6, 0);
            prep.setInt(7, this.getLectID());
            prep.setString(8, student.getStudID());
            prep.setInt(9, student.getTopic());
            prep.setString(10, venue);
            prep.execute();
            prep.close();
            c.close();
           }
           
            
        }catch(SQLException e){
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
    }

   public String getPassword() {
        return this.password;
    }

   public  boolean deleteStud(String studID) {
       boolean results = false;
           Connection c = conn.DBconn();
        try {
              
            String sql = "DELETE FROM Student WHERE StudID = ?;";
             PreparedStatement prep = c.prepareStatement(sql);
             prep.setString(1, studID);
            
           
             prep.execute();
                  String sql2 = "DELETE FROM Session WHERE StudID = ?;";
                  PreparedStatement prep2 = c.prepareStatement(sql2);
                  prep2.setString(1, studID);
                  prep2.execute();
             
            
        } catch (Exception e) {
             System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
        
        try {
            
           
                  String sql2 = "DELETE FROM Session WHERE StudID = ?;";
                  PreparedStatement prep2 = c.prepareStatement(sql2);
                  prep2.setString(1, studID);
                  prep2.execute();
                  c.close();
                  results = true;
            
        } catch (Exception e) {
             System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
        return results;
    }
}
   