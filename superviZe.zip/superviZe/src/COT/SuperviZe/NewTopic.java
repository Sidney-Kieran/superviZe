/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package COT.SuperviZe;

import static COT.SuperviZe.SignUp.removeAllStyle;
import java.sql.*;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import static javafx.scene.paint.Color.RED;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author CARTER
 */
public class NewTopic {
    public static boolean feedback;
    public static boolean createTopic(){
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        GridPane layout = new GridPane();
        layout.setHgap(30);
        ColumnConstraints column1 = new ColumnConstraints();
        column1.setPercentWidth(40);
        ColumnConstraints column2 = new ColumnConstraints();
        column2.setPercentWidth(60);
        layout.getColumnConstraints().addAll(column1, column2);
        
        Label heading = new Label("Create New Topic");
        Separator sep = new Separator();
        Label name = new Label("Project Title");
        TextField nameIn = new TextField();
        Label description = new Label("Topic Description");
        TextArea descriptionIn = new TextArea();
        descriptionIn.setPromptText("Enter brief description of the Project. Should be atmost 250words");
       
        descriptionIn.addEventFilter(KeyEvent.KEY_RELEASED, new EventHandler<KeyEvent>(){
		@Override
		public void handle(KeyEvent arg0) {
                    int i = 0;
			TextArea f=(TextArea)arg0.getSource();
			int length = f.getText().length();
                        String s = f.getText();
                        String[] words = s.split(" ");
                        int count = words.length;
                        
                        if(count <= 250){
                            removeAllStyle(f);
                            descriptionIn.getStyleClass().add("good");
                        }else if(count > 250){
                            descriptionIn.getStyleClass().add("weak");
                        }else{
                            removeAllStyle(f);
                        }
		}
	});        
        
        descriptionIn.setPrefColumnCount(5);
        descriptionIn.setPrefRowCount(8);
        descriptionIn.setWrapText(true);
        Button cancel = new Button("Cancel");
        cancel.setMinWidth(80);
        cancel.getStyleClass().add("btn");
        cancel.setOnAction(e -> window.close());
        Button create = new Button("Create");
        create.getStyleClass().add("btn");
        create.setMinWidth(80);
        create.setOnAction(e -> {
            String topic = "";
            String topDes = "";
            if(nameIn.getText().trim().isEmpty()){
                nameIn.clear();
                nameIn.promptTextProperty().set("Enter Project Name");
                nameIn.getStyleClass().add("err");
            }else{
                topic = nameIn.getText();
            }


            String s = descriptionIn.getText();
            String[] words = s.split(" ");
            int count = words.length;
            String desErr = "";
            if(descriptionIn.getText().trim().isEmpty()){
                descriptionIn.getStyleClass().add("err");
                desErr = "Enter Brief Description of Project";
                descriptionIn.promptTextProperty().set(desErr);
            }else if(count > 250){
                descriptionIn.getStyleClass().add("err");
                desErr = "Maximum text limit reach";
                Label err = new Label(desErr);
                err.setTextFill(RED);
                Boxes.alert("Limit Reached", desErr);
            }else{
                topDes = s;
            }
            
            if(!topic.isEmpty() && !topDes.isEmpty()){
                 Lecturer lec = new Lecturer("Sidney", "Ndula", 1);
                 lec.createTopic(topic, topDes);
            }
        });
        
        VBox head = new VBox(20);
        head.getStyleClass().add("addForm");
        head.getChildren().addAll(heading, sep);
        
        VBox form = new VBox(12);
        form.getStyleClass().add("addForm");
        form.getChildren().addAll(name, nameIn, description, descriptionIn);
        
        VBox list = new VBox(10);
        list.getStyleClass().add("list");
        
        HBox buttons = new HBox(84);
        buttons.getStyleClass().add("addForm");
        buttons.getChildren().addAll(cancel, create);
        
        layout.add(list, 0, 0);
        layout.add(head, 1, 0);
        layout.add(form, 1, 1);
        layout.add(buttons, 1, 2);
        GridPane.setRowSpan(list, 3);
        
        Scene scene = new Scene(layout, 500, 410);
        scene.getStylesheets().add("/COT/SuperviZe/theme.css");
        window.setScene(scene);
        window.setTitle("SuperviZe | Create Topic");
        window.getIcons().add(new Image("/COT/SuperviZe/photos/superviZe.png")); 
        window.setResizable(false);
       
        window.show();
        return feedback;
        
    }
    
}
