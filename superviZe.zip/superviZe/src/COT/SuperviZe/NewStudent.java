/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package COT.SuperviZe;

import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;

import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author CARTER
 */
public class NewStudent {
    static boolean feedback;
    public static boolean addStudent(){
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        GridPane layout1 = new GridPane();
        layout1.setHgap(30);
        GridPane layout2 = new GridPane();
        layout2.setHgap(30);
       
        ColumnConstraints column1 = new ColumnConstraints();
        column1.setPercentWidth(45);
        ColumnConstraints column2 = new ColumnConstraints();
        column2.setPercentWidth(55);
        layout1.getColumnConstraints().addAll(column1, column2);
        
        layout2.getColumnConstraints().addAll(column1, column2);
        
        //Children for scene1
        //Heading
        Label heading = new Label();
        Separator separator1 = new Separator();
        Separator separator2 = new Separator();
        separator2.getStyleClass().add("sep2");
        heading.setWrapText(true);
        heading.setText("Fill Student Information");
        heading.setTextAlignment(TextAlignment.CENTER);
        
        //Input fields for first scene
        Label name = new Label("Name");
        TextField nameIn = new TextField();
        Label matricule = new Label("Matricule");
        TextField matriculeIn = new TextField();
        Label email = new Label("E-mail");
        TextField emailIn = new TextField();
        Label number = new Label("Phone Number");
        TextField numberIn = new TextField();
        Button cancel = new Button("Cancel");
        cancel.setOnAction(e -> window.close());
        cancel.setMinWidth(80);
        cancel.getStyleClass().add("btn");
        Button next = new Button("Next >");
        next.setMinWidth(80);
        next.getStyleClass().add("btn");
        VBox form1 = new VBox(10);
        form1.getStyleClass().add("addForm");
        form1.getChildren().addAll(name, nameIn, matricule, matriculeIn, email, emailIn, number, numberIn);
        HBox buttons1 = new HBox(59);
        buttons1.getStyleClass().add("addForm");
        buttons1.getChildren().addAll(cancel, next);
        VBox head = new VBox(20);
        head.getStyleClass().add("head");
        head.getChildren().addAll(heading,separator1);
        
        //Scene 2 elements
        Label year = new Label("Academic Year");
        ChoiceBox<String> yearIn = new ChoiceBox<String>();
        DBConnect conn = new DBConnect();
        Connection connect = conn.DBconn();
        try{
            Statement stmt = connect.createStatement();
            String sql = "SELECT year FROM Year";
            ResultSet rs = stmt.executeQuery(sql);
            int i = 0;
            while(rs.next()){
                yearIn.getItems().add(rs.getString("year"));
                if(i == 0){
                    yearIn.setValue(rs.getString("year"));
                }
                i++;
            }
        }catch(SQLException ex){
            System.err.println( ex.getClass().getName() + ": " + ex.getMessage() );
            System.exit(0);
        }
        /*yearIn.getItems().add("2016/2017");
        yearIn.getItems().add("2017/2018");
        yearIn.getItems().add("2018/2019");
        yearIn.setValue("2016/2017");*/
        
        //empty labels to ease the design
        Label a = new Label("");
        Label b = new Label("");
        Label c = new Label("");
        Label d = new Label("");
        
        Label topic = new Label("Choose Topic");
        ChoiceBox<String> topicIn = new ChoiceBox<String>();
        try{
            Statement stmt = connect.createStatement();
            String sql = "SELECT TopTitle FROM Topic";
            ResultSet rs = stmt.executeQuery(sql);
             int j = 0;
            while(rs.next()){
                topicIn.getItems().add(rs.getString("TopTitle"));
                if(j == 0){
                 topicIn.setValue(rs.getString("TopTitle"));
                }
                stmt.close();
                rs.close();
            }
        }catch(SQLException ex){
            System.err.println( ex.getClass().getName() + ": " + ex.getMessage() );
            System.exit(0);
        }
        /*topicIn.getItems().add("Real Estate Website");
        topicIn.getItems().add("Bird Egg Incubator Design");
        topicIn.getItems().add("Home Suvelliance Sytem Design");
        topicIn.getItems().add("Application of Various Cryptographic Cypers");
        topicIn.setValue("Application of Various Cryptographic Cypers");*/
         
        Button previous = new Button("< Previous");
        previous.getStyleClass().add("btn");
        previous.setMinWidth(80);
        Button finish = new Button("Finish");
        finish.getStyleClass().add("btn");
        finish.setMinWidth(80);
        Button cancel1= new Button("Cancel");
        cancel.getStyleClass().add("btn");
        cancel1.setOnAction(e -> window.close());
        Label heading1 = new Label();
        heading1.setWrapText(true);
        heading1.setText("Fill Student Information");
        
        
        VBox form2 = new VBox(12);
        form2.getStyleClass().add("addForm");
        form2.getChildren().addAll(year, yearIn, topic, topicIn,a,b,c,d);
        
        HBox buttons2 = new HBox(59);
        buttons2.getStyleClass().add("addForm");
        buttons2.getChildren().addAll(previous, finish);
        VBox head1 = new VBox(20);
        head1.getStyleClass().add("head");
        head1.getChildren().addAll(heading1,separator2);
        
        
        
        
        
        //progess column
        Label num1 = new Label("1."+"  " + "Student's Personal Information");
        num1.getStyleClass().add("active");
        Label num2 = new Label("2."+"  " + "Student's Topic Information");
        VBox list = new VBox(10);
        list.getStyleClass().add("list");
        list.getChildren().addAll( num1, num2);
        
        Label num3 = new Label("1."+"  " + "Student's Personal Information");
        Label num4 = new Label("2."+"  " + "Student's Topic Information");
        num4.getStyleClass().add("active");
        VBox list1 = new VBox(10);
        list1.getStyleClass().add("list");
        list1.getChildren().addAll( num3, num4);
        
        
        //Adding scene1 nodes to grid
        layout1.add(list, 0,0);
        layout1.add(head, 1, 0);
        layout1.add(form1, 1, 1);
        layout1.add(buttons1, 1,2);
        GridPane.setRowSpan(list, 4);
        
       layout2.add(list1, 0,0);
       layout2.add(head1, 1, 0);
       layout2.add(form2, 1, 1);
       layout2.add(buttons2, 1, 2);
       GridPane.setRowSpan(list1, 4);
       
      
        
        
        Scene scene1 = new Scene(layout1,500, 395); 
        Scene scene2 = new Scene(layout2, 500, 395);
        next.setOnAction(e -> window.setScene(scene2));
        previous.setOnAction(e -> window.setScene(scene1));
         finish.setOnAction(e -> {
           String studName = "";
           String matriculeNum = "";
           String phoneNum = "";
           String studEmail = "";
           if(nameIn.getText().trim().isEmpty()){
               nameIn.getStyleClass().add("err");
               nameIn.promptTextProperty().set("Please! Enter Student's Name");
           }else if(!compareString(nameIn.getText())){
               nameIn.getStyleClass().add("err");
               nameIn.promptTextProperty().set("Name should contain only letters, white spaces and hyphens");
               nameIn.clear();
               nameIn.getStyleClass().add("err");
           }else{
               studName = nameIn.getText().trim();
           }
           
           if(matriculeIn.getText().trim().isEmpty()){
               matriculeIn.getStyleClass().add("err");
               matriculeIn.promptTextProperty().set("Please! Enter Student's Matricule");
           }else{
               matriculeNum = matriculeIn.getText().trim();
           }
           
           if(numberIn.getText().trim().isEmpty()){
              numberIn.getStyleClass().add("err");
              numberIn.promptTextProperty().set("Please! Enter Student's Phone Number");
           }else if(!compareInt(numberIn.getText())){
               numberIn.getStyleClass().add("err");
               numberIn.promptTextProperty().set("Phone number must contain only integers");
               numberIn.clear();
               numberIn.getStyleClass().add("err");
           }else{
               phoneNum = numberIn.getText().trim();
           }
           
           
           
           if(emailIn.getText().trim().isEmpty()){
              emailIn.getStyleClass().add("err");
              emailIn.promptTextProperty().set("Please! Enter Student's E-mail Address");
           }else if(!compareEmail(emailIn.getText())){
               emailIn.getStyleClass().add("err");
               emailIn.promptTextProperty().set("Wrong E-mail format");
               emailIn.clear();
               emailIn.getStyleClass().add("err");
           }else{
               studEmail = emailIn.getText().trim();
           }
            int topicID = 0;
           try{
               String sql = "SELECT * FROM Topic WHERE TopTitle = ?";
               PreparedStatement prep = connect.prepareStatement(sql);
               prep.setString(1, topicIn.getValue());
               ResultSet rs = prep.executeQuery();
               while(rs.next()){
                   topicID = rs.getInt("TopicID");
               }
               connect.close();
           }catch(SQLException ex){
               
           }
           if(!studEmail.isEmpty() && !phoneNum.isEmpty() && !matriculeNum.isEmpty() && !studName.isEmpty()){
               Year Studyear = new Year(yearIn.getValue());
               Topic Studtopic = new Topic(topicIn.getValue(), topicID);
               Lecturer lec = new Lecturer("Attiah Thomas", "Mih", 2);
               lec.addStudent(matriculeNum, studName, studEmail, phoneNum, Studyear, Studtopic);
           }else{
               window.setScene(scene1);
           }
       });
         
        scene1.getStylesheets().add("/COT/SuperviZe/theme.css");
        scene2.getStylesheets().add("/COT/SuperviZe/theme.css");
        window.setScene(scene1);
        window.setResizable(false);
        window.setTitle("SuperviZe | Add Student");
        window.getIcons().add(new Image("/COT/SuperviZe/photos/superviZe.png")); 
        window.show();
    
        return feedback;
    }
   
    
    
    public static boolean compareString(String s){      
     String regex="[A-Za-z\\s\\-]+";       
      return s.matches(regex);//returns true if input and regex matches otherwise false;
 }
    public static boolean compareInt(String s){
        String regex = "[0-9]+";
        return s.matches(regex);
    }
    public static final Pattern VALID_EMAIL_ADDRESS_REGEX = 
    Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
    public static boolean compareEmail(String s){
        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX .matcher(s);
        return matcher.find();
    }
}
