/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package COT.SuperviZe;

import java.sql.*;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;

import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author CARTER
 */
public class Boxes {
    
   
   static boolean feedback;
   public static boolean confirm(String title, String message){
      
       
       Stage window = new Stage();
       window.initModality(Modality.APPLICATION_MODAL);
       
       Button cancel = new Button("No");
       cancel.setMinWidth(60);
       cancel.getStyleClass().add("btn");
       Button okay = new Button("Yes");
       okay.getStyleClass().add("btn");
       okay.setMinWidth(60);
       Label msg = new Label();
       msg.setText(message);
       msg.setWrapText(true);
       msg.setTextAlignment(TextAlignment.CENTER);
       
       GridPane layout = new GridPane();
       layout.getStyleClass().add("confirm");
        ColumnConstraints column1 = new ColumnConstraints();
        column1.setPercentWidth(100);
        layout.getColumnConstraints().addAll(column1); // each get 50% of width
        
       layout.setHgap(60);
       layout.setVgap(10);
       
       HBox group = new HBox(15);
       group.alignmentProperty().set(Pos.CENTER);
       group.getChildren().addAll(cancel, okay);
      
       
       layout.add(msg, 0, 2);
       layout.add(group, 0, 4);
      
       layout.setHalignment(msg, HPos.CENTER);
        layout.setHalignment(group, HPos.CENTER);
       cancel.setOnAction(e ->{
           feedback = false;
           window.close();
       });
       
       okay.setOnAction(e ->{
           feedback = true;
           window.close();
       });
       
       Scene scene = new Scene(layout, 300, 100);
       window.setScene(scene);
       window.setResizable(false);
       scene.getStylesheets().add("/COT/SuperviZe/theme.css");
       window.setTitle(title);
       window.getIcons().add(new Image("/COT/SuperviZe/photos/superviZe.png")); 
       window.show();
       
       return feedback;
   }
   
   public static void alert(String title, String message){
      
       
       Stage window = new Stage();
       window.initModality(Modality.APPLICATION_MODAL);
       
       
       
       Button okay = new Button("OK");
       okay.getStyleClass().add("btn");
       okay.setMinWidth(60);
       Label msg = new Label();
       msg.setText(message);
       msg.setWrapText(true);
       msg.setTextAlignment(TextAlignment.CENTER);
       
       GridPane layout = new GridPane();
       layout.getStyleClass().add("confirm");
        ColumnConstraints column1 = new ColumnConstraints();
        column1.setPercentWidth(100);
        layout.getColumnConstraints().addAll(column1); // each get 50% of width
        
       layout.setHgap(60);
       layout.setVgap(10);
       
       HBox group = new HBox(15);
       group.alignmentProperty().set(Pos.CENTER);
       group.getChildren().addAll(okay);
      
       
       layout.add(msg, 0, 2);
       layout.add(group, 0, 4);
      
       layout.setHalignment(msg, HPos.CENTER);
        layout.setHalignment(group, HPos.CENTER);
  
       
       okay.setOnAction(e ->{
           
           window.close();
       });
       
       Scene scene = new Scene(layout, 300, 100);
       window.setScene(scene);
       window.setResizable(false);
       scene.getStylesheets().add("/COT/SuperviZe/theme.css");
       window.setTitle(title);
       window.getIcons().add(new Image("/COT/SuperviZe/photos/superviZe.png")); 
       window.show();
       
       
   }
    
}
