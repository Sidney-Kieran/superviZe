/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package COT.SuperviZe;

import javafx.animation.PauseTransition;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.*;
import javafx.util.Duration;
import java.io.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import sun.audio.*;

/**
 *
 * @author CARTER
 */
public class Notification {
    public static void newNotification(String date, String time, String venue, String student){
       
        
        Label heading = new Label("Upcomming Session");
        Separator sep1 = new Separator();
        Separator sep2 = new Separator();
        Label Date = new Label("Date       : " + date);
        Label Time = new Label("Time       : " + time);
        Label Student = new Label("Student  : " + student);
        Label Venue = new Label("Venue     : " + venue);
        Button ok = new Button("Okay");
        ok.setPrefWidth(70);
        ok.getStyleClass().add("btn");
        VBox btn = new VBox();
        btn.getChildren().add(ok);
        btn.setAlignment(Pos.CENTER);
        
        GridPane layout = new GridPane();
        ColumnConstraints col1= new ColumnConstraints();
        col1.setPercentWidth(40);
        ColumnConstraints col2= new ColumnConstraints();
        col2.setPercentWidth(60);
        layout.getColumnConstraints().addAll(col1, col2);
        
        VBox body = new VBox(5);
        body.getStyleClass().add("addForm");
        body.getChildren().addAll(heading, sep1, Date, Time, Student, Venue, sep2, btn);
        VBox list = new VBox();
        list.getStyleClass().add("list");
        Image logo = new Image("/COT/SuperviZe/photos/superviZe.png");
        ImageView view = new ImageView(logo);
        view.setFitHeight(110);
        view.setFitWidth(110);
        view.setPreserveRatio(true);
        view.getImage();
        list.getChildren().add(view);
        
        layout.add(body, 1, 0);
        layout.add(list, 0, 0);
       
        
        
       String sound = Notification.class.getResource("/COT/SuperviZe/Sounds/iPhone Original SMS Sound0.mp3").toString();
       Media hit = new Media(sound);
       MediaPlayer mediaPlayer = new MediaPlayer(hit);
       mediaPlayer.play();
        
            
       
       
  
        
        Scene scene = new Scene(layout, 310, 180 );
        scene.getStylesheets().add("/COT/SuperviZe/theme.css");
        Stage window = new Stage();
        ok.setOnAction(e -> {
            mediaPlayer.stop();
            window.close();
                });
        window.setScene(scene);
        window.setTitle("SuperviZe | SuperviZe Easily and Effectively");
        window.getIcons().add(new Image("/COT/SuperviZe/photos/superviZe.png"));
        window.initStyle(StageStyle.UNDECORATED);
        window.initModality(Modality.WINDOW_MODAL);
        window.setX(1000); //secondStage.setX(primaryStage.getX() + 250);
        window.setY(550);
        window.show();
        PauseTransition delay = new PauseTransition(Duration.seconds(10));
        delay.setOnFinished(event -> {
            mediaPlayer.stop();
            window.close();
                });
        delay.play();
    }
}
