/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package COT.SuperviZe;

/**
 *
 * @author CARTER
 */
public class Topic {

    public Topic(String name, int TopicID) {
        this.name = name;
        this.TopicID = TopicID;
    }
    
    private String name;
    private int TopicID;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTopicID() {
        return TopicID;
    }

    public void setTopicID(int TopicID) {
        this.TopicID = TopicID;
    }

    
    
}
