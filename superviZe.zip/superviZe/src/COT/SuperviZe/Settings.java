/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
    
package COT.SuperviZe;

import java.sql.*;

/**
 *
 * @author CARTER
 */
public class Settings {
    
    //method to change userName
    
    public String changeUsername(String newUserName, Lecturer lec){
        
        DBConnect conn = new DBConnect();
        Connection c = conn.DBconn();
        String comment = "";
        
        try{
        Statement stmt = c.createStatement();
        String sql = "UPDATE Lecturer(Username)"+
                "VALUES("+newUserName+")"+
                "WHERE(LecID="+lec.getLectID()+");";
        stmt.executeUpdate(sql);
        stmt.close();
        comment = "Username has been updated successfully";
    }
        catch(SQLException e){
             System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
        return comment;
        
    }
    
    //method to change Password
      public String changePassword(String oldPassword, String newPassword, Lecturer lec){
        
        DBConnect conn = new DBConnect();
        Connection c = conn.DBconn();
        String comment = "";
        
        if(oldPassword.equals(lec.getPassword())){
              try{
        Statement stmt = c.createStatement();
        String sql = "UPDATE Lecturer(Lpassword)"+
                "VALUES("+newPassword+")"+
                "WHERE(LecID="+lec.getLectID()+");";
        stmt.executeUpdate(sql);
        stmt.close();
        comment = "Username has been updated successfully";
    }
        catch(SQLException e){
             System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
        }else{
            comment = "Wrong Password Entered! Enter correct old password";
        }
        
      
        return comment;
        
    }
      
      
    
}
