/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package COT.SuperviZe;

import java.sql.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author CARTER
 */
public class ObservableSession {
    
    static ObservableList<SessionList> getSessions;
     static ObservableList<SessionList> Sessions = FXCollections.observableArrayList();
    public static ObservableList<SessionList> list() {
        DBConnect conn = new DBConnect();
        Connection c = conn.DBconn();
        
        try{
            Statement stmt = c.createStatement();
            String sql = "SELECT *"
                    + "FROM Session";
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
               String sql2 = "SELECT Sname FROM Student WHERE StudID = ?";
               PreparedStatement prep = c.prepareStatement(sql2);
               prep.setString(1, rs.getString("StudID"));
               ResultSet rs2 = prep.executeQuery();
               while(rs2.next()){
                   //System.out.println(rs.getString("SessionDate") + " " + rs.getString("SessionTime") + " " + rs2.getString("Sname") + " " + rs.getString("SessionVenue"));
                  
                  
                   Sessions.add(new SessionList(rs2.getString("Sname"), rs.getString("SessionVenue"), rs.getString("SessionDate"), rs.getString("SessionTime") ));
                  
               }
            }
            c.close();
        }catch(SQLException e){
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
        
        return Sessions;
        
    }
    
}
