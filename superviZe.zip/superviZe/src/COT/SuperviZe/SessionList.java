/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package COT.SuperviZe;

/**
 *
 * @author CARTER
 */
public class SessionList{
    
    private String studName;
    private String venue;
    private String date;
    private String time;
    private String dateTime;

    public SessionList(String studName, String venue, String date, String time) {
        this.studName = studName;
        this.venue = venue;
        this.date = date;
        this.time = time;
        this.dateTime = date + " " + time;
    }

    public String getDateTime() {
        return dateTime;
    }

    public String getStudName() {
        return studName;
    }

    public void setStudName(String studName) {
        this.studName = studName;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
    
    
}
