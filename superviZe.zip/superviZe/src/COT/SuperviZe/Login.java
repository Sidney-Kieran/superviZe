/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package COT.SuperviZe;

import java.sql.*;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import static javafx.scene.paint.Color.*;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author CARTER
 */
public class Login{
    
   
    public static Scene login(){
        Stage window;
        Scene scene;
        window = new Stage();
       window.setTitle("SuperviZe | Please Login");
        window.getIcons().add(new Image("/COT/SuperviZe/photos/superviZe.png")); 
        
        GridPane group = new GridPane();
         group.getStyleClass().add("grid");
        ColumnConstraints column1 = new ColumnConstraints();
        column1.setPercentWidth(40);
        ColumnConstraints column2 = new ColumnConstraints();
        column2.setPercentWidth(60);
        group.getColumnConstraints().addAll(column1, column2); // each get 50% of width
        
        group.setHgap(30);
       
        Image logo = new Image("/COT/SuperviZe/photos/superviZe_logo.png");
        ImageView view = new ImageView(logo);
        view.setFitHeight(310);
        view.setFitWidth(210);
        view.setPreserveRatio(true);
        view.getImage();
       
        
       //Form
       Label usernameLabel = new Label("Username");
        Label err = new Label("");
        Label Uerr = new Label("");
        Label Perr = new Label("");
        Uerr.setWrapText(true);
        Uerr.setTextFill(RED);
        Perr.setWrapText(true);
        Perr.setTextFill(RED);
       TextField username = new TextField();
       Label usernamePassword = new Label("Password");
       TextField password = new PasswordField();
       Button login = new Button("Login");
       login.setMinWidth(60);
       login.getStyleClass().add("btn");
       login.setOnAction(e -> {
           int i = 0;
           String name = "";
           String Surname = "";
           int LecID = 0;
           String errLogin = "";
           String usernameErr = "";
           String pwErr = "";
           String us = "";
           String pw = "";
           if(username.getText().trim().isEmpty()){
              usernameErr= "Please! Enter your username";
               username.getStyleClass().add("err");
               username.clear();
               username.promptTextProperty().set(usernameErr);
           }
           else {
               us = username.getText().trim();
           }
           if(password.getText().trim().isEmpty()){
               usernameErr = "";
               pwErr = "Please! Enter your password";
               password.getStyleClass().add("err");
               password.clear();
               password.promptTextProperty().set(pwErr);
               
           }else{
               pw = password.getText().trim();
           }
           if(usernameErr.isEmpty() && pwErr.isEmpty()){
               DBConnect conn = new DBConnect();
               Connection c = conn.DBconn();
               String sql =  "SELECT * FROM Lecturer WHERE Username = ? AND Lpassword = ?";
            try{
                PreparedStatement prep = c.prepareStatement(sql);
                prep.setString(1, us);
                prep.setString(2, pw);
                ResultSet rs = prep.executeQuery();
                
            if(rs.next()){
                err.setText("");
                username.getStyleClass().removeAll("err");
                password.getStyleClass().removeAll("err");
                username.getStyleClass().add("correct");
                password.getStyleClass().add("correct");
                name = rs.getString("Lname");
                Surname = rs.getString("Lsurname");
                LecID = rs.getInt("LecID");
                System.out.println("User logged in");
                Lecturer lec = new Lecturer(name, Surname, LecID);
                rs.close();
                prep.close();
            }else{
                username.getStyleClass().add("err");
                password.getStyleClass().add("err");
                password.clear();
                username.clear();
                Boxes.alert("Login Error", "Wrong Username/Password Combination");
                errLogin = "Enter Correct Username/Password...";
                err.setAlignment(Pos.CENTER);
                err.setWrapText(true);
                err.setTextFill(RED);
                err.setText(errLogin);
            }
            }catch(SQLException ex){
                System.err.println( ex.getClass().getName() + ": " + ex.getMessage() );
                System.exit(0);
            }
               
           }
           
      
     
   });     
       
       //layout
       VBox layout = new VBox(10);
       layout.getStyleClass().add("confirm");
       layout.setPadding(new Insets(20, 30, 20, 30));
       layout.getChildren().addAll(err ,usernameLabel, username ,usernamePassword, password, login);
       VBox col1 = new VBox(10);
       col1.setPadding(new Insets(30, 0, 0, 0));
         col1.getChildren().addAll(view);
          col1.getStyleClass().add("greeting");
          group.add(col1, 0,1);
       group.add(layout, 1, 1);
       
       scene = new Scene(group, 480, 218);
       scene.getStylesheets().add("/COT/SuperviZe/theme.css");
       
       return scene;
    }

    /**
     * @param args the command line arguments
     */
    
}
