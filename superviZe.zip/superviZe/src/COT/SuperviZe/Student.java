/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package COT.SuperviZe;

import java.sql.*;

/**
 *
 * @author CARTER
 */
public class Student {
    
    private String name;
    private String studID;
    DBConnect conn = new DBConnect();

    public Student(String name, String studID) {
        this.name = name;
        this.studID = studID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStudID() {
        return studID;
    }

    public void setStudID(String studID) {
        this.studID = studID;
    }

    public int getTopic() {
        int TopicID = 0;
        Connection c = conn.DBconn();
       try{
         String  sql = "SELECT TopicID FROM Student WHERE StudID = ?";
         PreparedStatement prep = c.prepareStatement(sql);
         prep.setString(1, this.getStudID());
         ResultSet rs = prep.executeQuery();
       while ( rs.next() ) {
        TopicID = rs.getInt("TopicID");
        rs.close();
       }
       c.close();
       }catch(SQLException e){
           System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
       }
        
       return TopicID; 
       
    }
    
    public int getAttendance(){
        int attendance = 0;
        Connection c = conn.DBconn();
        try{
            Statement stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT StudAttendance FROM Session" + 
                           "WHERE StudentID =" + this.getStudID() +
                            "AND StudAttendance = 1 ;");
            while(rs.next()){
                attendance ++;
                rs.close();
            }
        }catch(SQLException e){
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
        
        return attendance;
    }
    
    
    
}
