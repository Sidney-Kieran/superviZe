/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package COT.SuperviZe;

import static COT.SuperviZe.SignUp.removeAllStyle;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.concurrent.CountDownLatch;
import javafx.animation.KeyFrame;
import javafx.animation.PauseTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.concurrent.Service;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 *
 * @author CARTER
 */
public class Main extends Application {
    
    
    
     private void checkReminders() {
    if (ReminderList.list().isEmpty() == false) {
        SimpleDateFormat sdfDate = new SimpleDateFormat("dd/MM/YYYY HH:mm:ss");
        Date date = new Date(System.currentTimeMillis() + 3600 * 4000);
        for (Reminder session : ReminderList.list()) {
                if (sdfDate.format(date).equals(session.getDateTime())) {
                    Notification.newNotification(session.getDate(), session.getTime(), session.getVenue(), session.getStudName());
                    ReminderList.list().remove(session);
                }
        }
    }
}
    
    Lecturer lec = new Lecturer("Sidney", "Ndula", 1);
    Stage window;
    
    @Override
    public void start(Stage primaryStage) {
        
        
        window = primaryStage;

   
        VBox borderleft = new VBox(20);
        borderleft.setPadding(new Insets(20));
        borderleft.getStyleClass().add("borderleft");
        borderleft.setPrefWidth(500);
        HBox search = new HBox(10);
        
        ChoiceBox<String> yearIn = new ChoiceBox<String>();
        Calendar now= Calendar.getInstance();//Gets System time
        int currentYear = now.get(Calendar.YEAR);//Gets the year potion of system time
        
         DBConnect conn = new DBConnect();
        Connection connect = conn.DBconn();
        try{
            Statement stmt = connect.createStatement();
            String sql = "SELECT year FROM Year";
            ResultSet rs = stmt.executeQuery(sql);
            int i = 0;
            while(rs.next()){
                yearIn.getItems().add(rs.getString("year"));
                if(i == 0){
                    yearIn.setValue(rs.getString("year"));
                }
                i++;
            }
            stmt.close();
            rs.close();
        }catch(SQLException ex){
            System.err.println( ex.getClass().getName() + ": " + ex.getMessage() );
            System.exit(0);
        }
        
        TextField searchField = new TextField();
        String studIn = searchField.getText();
        searchField.setPromptText("Enter name of student to search");
        searchField.setPrefWidth(200);
        
        Button searchButton = new Button();
        searchButton.setText("Search");
        searchButton.setPrefWidth(80);
        searchButton.getStyleClass().add("btn");
        search.setAlignment(Pos.CENTER);
        search.getChildren().addAll(yearIn, searchField, searchButton);
        
       
        
        Menu user = new Menu("Dr.Ndula");
        ImageView profilePic = new ImageView("/COT/SuperviZe/photos/superviZe.png");
        profilePic.setFitHeight(16);
        profilePic.setFitWidth(25);
        Menu home = new Menu("Home");
        MenuItem homeItem = new MenuItem("Home");
        home.getItems().add(homeItem);
       
        
        MenuBar homeMenu = new MenuBar();
        homeMenu.getMenus().add(home);
        homeMenu.setPrefWidth(67);
        
        
        user.setGraphic(profilePic);
        MenuItem profile = new MenuItem("Profile");
        MenuItem logout = new MenuItem("Logout");
        user.getItems().addAll(profile, logout);
        MenuBar userBar = new MenuBar();
        userBar.getMenus().add(user);
       
        
        MenuBar navControls = NavBar.topMenu();
        navControls.setPrefWidth(1182);
        
        
        HBox nav = new HBox(0);
        nav.getChildren().addAll(homeMenu,navControls, userBar);
        
        
        VBox borderleftList = new VBox(20);
        borderleftList.setPadding(new Insets(20));
        
        borderleftList.getStyleClass().add("borderleftList");
        ScrollPane scroll = new ScrollPane(borderleftList);
        scroll.getStyleClass().add("scroll");
        scroll.setMinHeight(600);
        scroll.setMaxHeight(600);
        
        //Context menu on right click on the student's name
        final ContextMenu contextMenu = new ContextMenu();
        MenuItem edit = new MenuItem("Edit Student's Profile");
        edit.getStyleClass().clear();
        edit.getStyleClass().add("contextMenuItem");
        contextMenu.getStyleClass().add("stud");
        MenuItem delete = new MenuItem("Delete this Student");
        delete.getStyleClass().clear();
        delete.getStyleClass().add("contextMenuItem");
        SeparatorMenuItem sep = new SeparatorMenuItem();
        contextMenu.getItems().addAll(edit, sep, delete);
        
        int i = 0;//student count
        try{
            Statement stmt = connect.createStatement();
            String sql = "SELECT StudID, SName FROM Student";
            ResultSet rs = stmt.executeQuery(sql);
            
            while(rs.next()){
                String studName = rs.getString("SName");
                String studID = rs.getString("StudID");
                Button stud = new Button(studName + "     " + studID);
                stud.setOnMouseClicked(new EventHandler<MouseEvent>(){
                    @Override
                    public void handle(MouseEvent event){
                        MouseButton button =event.getButton();
                        delete.setOnAction(e -> {
                            if(Boxes.confirm("Confirm Delete", "Are "
                                    + "you sure you want to delete "+ studName)){
                                if(lec.deleteStud(studID)){
                                Boxes.alert("Student Deleted", studName + " deleted successfully, "
                                       + "changes will take effect when you restart superViZe");
                            }
                            }else{
                                System.out.println("student not deleted");
                            }
                            
                                });
                        if(button == MouseButton.SECONDARY){
                            //System.out.println("Right click pressed");
                            contextMenu.show(stud, event.getScreenX(), event.getScreenY());
                        }
                    }
                    
                });
                
                stud.setPrefWidth(414);
                stud.setPrefHeight(33);
                
                stud.getStyleClass().add("stud");
                borderleftList.getChildren().add(stud);
                i++;
            }
            stmt.close();
            rs.close();
        }catch(SQLException ex){
            System.err.println( ex.getClass().getName() + ": " + ex.getMessage() );
            System.exit(0);
        }
        
        Button createYear = new Button("Create New Year");
        createYear.setOnAction(e -> NewYear.createYear());
        createYear.getStyleClass().add("btn");
        
        StackPane btn = new StackPane();
        btn.getChildren().add(createYear);
        
        Label heading = new Label("Welcome to SuperviZe");
        heading.setPadding(new Insets(0, 0, 0, 150));
        String message = "Thank you for signing up to SuperviZe."
                        +"To get started and effectively manage your students, Please create a year ehere in your students will be registered."+
                         "After which you can add project topics. Create and manage your schedules effectively."+
                        "We wish you find SuperviZe a convinient environment. Click the button below to create year.";
        Label welcomeText = new Label();
        welcomeText.wrapTextProperty().set(true);
        welcomeText.setText(message);
        welcomeText.setTextAlignment(TextAlignment.CENTER);
        
        Label welcome = new Label();
        
        borderleft.getChildren().addAll(search, scroll);
        
        //table
        TableColumn<SessionList, String> dateColumn = new TableColumn<>("Date");
        dateColumn.setMinWidth(203);
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        
        TableColumn<SessionList, String> timeColumn = new TableColumn<>("Time");
        timeColumn.setMinWidth(203);
        timeColumn.setCellValueFactory(new PropertyValueFactory<>("time"));
        
        TableColumn<SessionList, String> studNameColumn = new TableColumn<>("Student");
        studNameColumn.setMinWidth(204);
        studNameColumn.setCellValueFactory(new PropertyValueFactory<>("studName"));
        
        TableColumn<SessionList, String> venueColumn = new TableColumn<>("Venue");
        venueColumn.setMinWidth(210);
        venueColumn.setCellValueFactory(new PropertyValueFactory<>("venue"));
        
        TableView table = new TableView<>();
        table.setItems(ObservableSession.list());
        table.getColumns().addAll(dateColumn, timeColumn, studNameColumn, venueColumn);
        
        Button viewSessions = new Button("LIST OF UPCOMMING SESSIONS");
        viewSessions.getStyleClass().add("btn");
        viewSessions.setOnAction(e -> Notification.newNotification("12/06/2016", "8:00", "My Office", "Sirri Faith Che"));
        viewSessions.setAlignment(Pos.CENTER);
        viewSessions.setPrefWidth(820);
        
        VBox borderRight = new VBox(20);
        VBox borderRightTop = new VBox(20);
        borderRight.setPadding(new Insets(20));
        borderRightTop.getStyleClass().add("borderRightTop");
        borderRightTop.setPrefHeight(400);
        borderRightTop.setPadding(new Insets(20));
        VBox borderRightBottom = new VBox(20);
        borderRightTop.getChildren().add(new Label("Hello"));
        borderRightBottom.getChildren().addAll(viewSessions, table);
      
        borderRightBottom.setPrefHeight(400);
        borderRight.getChildren().addAll(borderRightTop, borderRightBottom);
        
        BorderPane root = new BorderPane();
        root.setRight(null);
        root.setTop(nav);
        root.setLeft(borderleft);
        root.setCenter(borderRight);
        
        Scene scene = new Scene(root, 1500, 1500);
        
        VBox greeting = new VBox(30);
        greeting.setPrefWidth(410);
        greeting.getChildren().addAll(heading, welcomeText, btn);
        greeting.setPadding(new Insets(150, 0, 0, 0));
        
        if(i==0){
            borderleftList.getChildren().clear();
            borderleftList.getChildren().add(greeting);
        }
        
        searchButton.setOnAction(e -> {
            if(searchField.getText().isEmpty()){
                
            }else{
                ArrayList<String> resultList = Search.searchIt(yearIn.getValue(), searchField.getText());
                if(resultList.size() == 0){
                    
                }else{
                    borderleftList.getChildren().clear();
                    for (int j = 0; j < resultList.size(); j++) {
                        String[] resultSplit = resultList.get(j).split("     ");
                        //System.out.println(resultList.get(j));
                        
                        Button result = new Button(resultList.get(j));
                        result.setOnMouseClicked(new EventHandler<MouseEvent>(){
                           @Override
                           public void handle(MouseEvent event){
                               MouseButton button =event.getButton();
                               delete.setOnAction(e -> {
                                   if(Boxes.confirm("Confirm Delete", "Are "
                                           + "you sure you want to delete "+ resultSplit[0])){
                                       if(lec.deleteStud(resultSplit[1])){
                                       Boxes.alert("Student Deleted", resultSplit[0] + " deleted successfully, "
                                              + "changes will take effect when you restart superViZe");
                                   }
                                   }else{
                                       System.out.println("student not deleted");
                                   }

                                       });
                               if(button == MouseButton.SECONDARY){
                                   //System.out.println("Right click pressed");
                                   contextMenu.show(result, event.getScreenX(), event.getScreenY());
                               }
                           }

                       });
                        result.setPrefWidth(414);
                        result.setPrefHeight(33);
                        result.getStyleClass().add("stud");
                        borderleftList.getChildren().add(result);
                    }
                    
                    resultList.clear();
                }
                
            }
        });
        
        searchField.addEventFilter(KeyEvent.KEY_RELEASED, new EventHandler<KeyEvent>(){
		@Override
		public void handle(KeyEvent arg0) {
			TextField f=(TextField)arg0.getSource();
			int length = f.getText().length();

	        if(length == 0){
                    borderleftList.getChildren().clear();
                    try{
                 Statement stmt = connect.createStatement();
                 String sql = "SELECT StudID, SName FROM Student";
                 ResultSet rs = stmt.executeQuery(sql);

                 while(rs.next()){
                     String studName = rs.getString("SName");
                     String studID = rs.getString("StudID");
                     Button stud = new Button(studName + "     " + studID);
                     stud.setOnMouseClicked(new EventHandler<MouseEvent>(){
                         @Override
                         public void handle(MouseEvent event){
                             MouseButton button =event.getButton();
                             delete.setOnAction(e -> {
                                 if(Boxes.confirm("Confirm Delete", "Are "
                                         + "you sure you want to delete "+ studName)){
                                     if(lec.deleteStud(studID)){
                                     Boxes.alert("Student Deleted", studName + " deleted successfully, "
                                            + "changes will take effect when you restart superViZe");
                                 }
                                 }else{
                                     System.out.println("student not deleted");
                                 }

                                     });
                             if(button == MouseButton.SECONDARY){
                                 //System.out.println("Right click pressed");
                                 contextMenu.show(stud, event.getScreenX(), event.getScreenY());
                             }
                         }

                     });

                     stud.setPrefWidth(414);
                     stud.setPrefHeight(33);

                     stud.getStyleClass().add("stud");
                     borderleftList.getChildren().add(stud);
                 }
                 stmt.close();
                 rs.close();
             }catch(SQLException ex){
                 System.err.println( ex.getClass().getName() + ": " + ex.getMessage() );
                 System.exit(0);
             }
                             }


                     }
             });
        

        
        
        homeItem.setOnAction(e -> window.setScene(scene));
        
        scene.getStylesheets().add("/COT/SuperviZe/theme.css");
        window.setMaximized(true);
        window.setScene(scene);
        window.setTitle("SuperviZe | SuperviZe Easily and Effectively");
        window.getIcons().add(new Image("/COT/SuperviZe/photos/superviZe.png"));
        window.show();
          
        
        /*PauseTransition delay = new PauseTransition(Duration.seconds(5));
        delay.setOnFinished(event -> window.close());
        delay.play();*/
        Timeline timeline = new Timeline(new KeyFrame( 
        Duration.millis(1000),
        ae -> checkReminders()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
   
    
}
