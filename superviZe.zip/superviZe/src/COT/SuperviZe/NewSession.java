/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package COT.SuperviZe;


import static COT.SuperviZe.NewStudent.compareInt;
import static COT.SuperviZe.SignUp.removeAllStyle;
import java.sql.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Locale;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import static javafx.scene.paint.Color.RED;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author CARTER
 */
public class NewSession {
    static boolean feedback;
    public static Lecturer lec = new Lecturer("Sidney", "Ndula", 1);
    public static boolean createSession(){
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        GridPane layout1 = new GridPane();
        layout1.setHgap(30);
        GridPane layout2 = new GridPane();
        layout2.setHgap(30);
       
        ColumnConstraints column1 = new ColumnConstraints();
        column1.setPercentWidth(45);
        ColumnConstraints column2 = new ColumnConstraints();
        column2.setPercentWidth(55);
        layout1.getColumnConstraints().addAll(column1, column2);
        layout2.getColumnConstraints().addAll(column1, column2);
        
        Scene scene1 = new Scene(layout1,500, 440); 
        Scene scene2 = new Scene(layout2, 500, 440);
        
        //Children for scene1
        //Heading
        Label heading = new Label();
        Separator separator1 = new Separator();
        heading.setWrapText(true);
        heading.setText("Fill Session Information");
        heading.setTextAlignment(TextAlignment.CENTER);
        
        //Student
        Label student = new Label("Student");
        ComboBox studentIn= new ComboBox();
        DBConnect conn = new DBConnect();
        Connection connect = conn.DBconn();
        try{
            Statement stmt = connect.createStatement();
            String sql = "SELECT Sname, StudID FROM Student";
            ResultSet rs = stmt.executeQuery(sql);
            int i = 0;
            while(rs.next()){
                studentIn.getItems().add(rs.getString("Sname") +" " + " " + rs.getString("StudID"));
                if(i == 0){
                    studentIn.setValue(rs.getString("Sname") +" "  +" " + rs.getString("StudID"));
                }
                i++;
            }
        }catch(SQLException ex){
            System.err.println( ex.getClass().getName() + ": " + ex.getMessage() );
            System.exit(0);
        }
        
        Label date = new Label("Date");
        DatePicker dateIn = new DatePicker();
        dateIn.setPrefWidth(500);
        Label hour = new Label("Hour");
        Spinner<Integer> hourIn = new Spinner<>(00, 23, 1);
        Label minute = new Label("Minute");
        Spinner<Integer> minuteIn = new Spinner<>(00, 59, 1);
        Button cancel = new Button("Cancel");
        cancel.setMinWidth(80);
        cancel.getStyleClass().add("btn");
        cancel.setOnAction(e -> window.close());
        Button next = new Button("Next >");
        next.setMinWidth(80);
        next.getStyleClass().add("btn");
        Button previous = new Button("< Previous");
        previous.setMinWidth(80);
        previous.getStyleClass().add("btn");
        Button create = new Button("Finish");
        create.setMinWidth(80);
        create.getStyleClass().add("btn");
         Label a = new Label("");
        Label b = new Label("");
        Label c = new Label("");
        Label d = new Label("");
        
        VBox head1 = new VBox(12);
        head1.getChildren().addAll(heading, separator1);
        head1.getStyleClass().add("head");
        
        VBox hourBox = new VBox(12);
        hourBox.getChildren().addAll(hour, hourIn);
        VBox minBox = new VBox(12);
        minBox.getChildren().addAll(minute, minuteIn);
        HBox timeBox = new HBox(49);
        timeBox.getChildren().addAll(hourBox, minBox);
        
        VBox form1 = new VBox(20);
        form1.getChildren().addAll(student, studentIn, date, dateIn, timeBox, a, b);
        form1.getStyleClass().add("addForm");
        
        HBox buttons1 = new HBox(59);
        buttons1.getChildren().addAll(cancel, next);
        buttons1.getStyleClass().add("addForm");
        
        
        //Form2
        Label num3 = new Label("1."+"  " + "Create Session | Step 1");
        Label num4 = new Label("2."+"  " + "Create Session | Step 2");
        num4.getStyleClass().add("active");
        VBox list2 = new VBox(10);
        list2.getStyleClass().add("list");
        list2.getChildren().addAll( num3, num4);
        
        Label heading2 = new Label();
        heading2.setWrapText(true);
        heading2.setText("Fill Student Information");
        Separator separator2 = new Separator();
        separator2.getStyleClass().add("sep2");
        
        
        Label duration = new Label("Duration(In Minutes)");
        TextField durationIn = new TextField();
        Label venue = new Label("Venue");
        ComboBox venueIn = new ComboBox();
        venueIn.setPrefWidth(500);
        venueIn.setEditable(true);
        try{
            Statement stmt = connect.createStatement();
            String sql = "SELECT venue FROM Venue";
            ResultSet rs = stmt.executeQuery(sql);
            int i = 0;
            while(rs.next()){
                venueIn.getItems().add(rs.getString("venue"));
                if(i == 0){
                    venueIn.setValue(rs.getString("venue"));
                }
                i++;
            }
        }catch(SQLException ex){
            System.err.println( ex.getClass().getName() + ": " + ex.getMessage() );
            System.exit(0);
        }
        
        Label work = new Label("Work");
        TextArea workIn = new TextArea();
        workIn.promptTextProperty().set("Enter brief work description(Atmost 100words)");
        workIn.addEventFilter(KeyEvent.KEY_RELEASED, new EventHandler<KeyEvent>(){
		@Override
		public void handle(KeyEvent arg0) {
			TextArea f=(TextArea)arg0.getSource();
                        String s = f.getText();
                        String[] words = s.split(" ");
                        int count = words.length;
                        
                        if(count <= 100){
                            removeAllStyle(f);
                            workIn.getStyleClass().add("good");
                        }else if(count > 100){
                            workIn.getStyleClass().add("weak");
                        }else{
                            removeAllStyle(f);
                        }
		}
	});        
        workIn.setPrefColumnCount(5);
        workIn.setPrefRowCount(4);
        workIn.setWrapText(true);
        
        //progress column1
        Label num1 = new Label("1."+"  " + "Create Session | Step 1");
        num1.getStyleClass().add("active");
        Label num2 = new Label("2."+"  " + "Create Session | Step 2");
        VBox list = new VBox(10);
        list.getStyleClass().add("list");
        list.getChildren().addAll( num1, num2);
        
        VBox head2 = new VBox(12);
        head2.getChildren().addAll(heading2, separator2);
        head2.getStyleClass().add("head");
        
        
        VBox form2 = new VBox(20);
        form2.getChildren().addAll(duration, durationIn, venue, venueIn, work, workIn);
        form2.getStyleClass().add("addForm");
        
        HBox buttons2 = new HBox(59);
        buttons2.getChildren().addAll(previous, create);
        buttons2.setPadding(new Insets(36, 20, 9, 20));
        
        create.setOnAction(e -> {
           String n = (String) studentIn.getValue();
           String[] s = n.split(" "+" ");
           String name = s[0];
           String matricule = s[1];
           Student stud = new Student(name, matricule);
           String SessionDate = "";
           String SessionHour = "";
           String SessionMinute = "";
           String SessionTime;
           String finalSessionTime = "";
           String SessionVenue = "";
           String SessionDuration = "";
           String SessionWork = "";
           if(dateIn.getValue() == null){
              dateIn.getStyleClass().add("err");
           }else{
               dateIn.getStyleClass().remove("err");
               SessionDate = DateToString(dateIn.getValue());
           }
           if(hourIn.getValue().toString().length() == 1){
               SessionHour = 0 + hourIn.getValue().toString();
           }else{
               SessionHour = hourIn.getValue().toString();
           }
           if(minuteIn.getValue().toString().length() == 1){
               SessionMinute = 0 + minuteIn.getValue().toString();
           }else{
               SessionMinute = minuteIn.getValue().toString();
           }
           
           SessionTime = SessionHour + ":" + SessionMinute + ":" + "00";
           if(dateIn.getValue() != null){
               finalSessionTime = SessionDate + " " + SessionTime;
           }
           
           if(venueIn.getValue() == null){
               venueIn.getStyleClass().add("err");
               venueIn.promptTextProperty().set("Enter venue or choose one from list");
           }else{
               venueIn.getStyleClass().remove("err");
               SessionVenue = venueIn.getValue().toString();
               try{
                   String sql = "SELECT venue FROM Venue WHERE venue = ?";
                   PreparedStatement prep = connect.prepareStatement(sql);
                   prep.setString(1, SessionVenue);
                   ResultSet rs = prep.executeQuery();
                   if(rs.next()){
                       prep.close();
                       rs.close();
                   }else{
                       try{
                           sql = "INSERT INTO Venue(venue, LecID) VALUES(?, ?)";
                           prep = connect.prepareStatement(sql);
                           prep.setString(1, SessionVenue);
                           prep.setInt(2, lec.getLectID());
                           prep.execute();
                           prep.close();
                       }catch(SQLException excep){
                          System.err.println( e.getClass().getName() + ": " + excep.getMessage() );
                          System.exit(0);
                       }
                   }
               }catch(SQLException ex){
                   System.err.println( e.getClass().getName() + ": " + ex.getMessage() );
                   System.exit(0);
               }
               
           }
           
           if(durationIn.getText().isEmpty()){
               durationIn.getStyleClass().add("err");
               durationIn.promptTextProperty().set("Please Enter the duration in minutes");
           }else if(!compareInt(durationIn.getText())){
               durationIn.getStyleClass().add("err");
               durationIn.clear();
               durationIn.promptTextProperty().set("Duration must be numbers");
           }else{
               SessionDuration = durationIn.getText().trim();
           }
           
           String st = workIn.getText();
            String[] words = st.split(" ");
            int count = words.length;
            String desErr = "";
            if(workIn.getText().trim().isEmpty()){
                workIn.getStyleClass().add("err");
                desErr = "Enter Work to be done for this Session";
                workIn.promptTextProperty().set(desErr);
            }else if(count > 100){
                workIn.getStyleClass().add("err");
                desErr = "Maximum text limit reach";
                Label err = new Label(desErr);
                err.setTextFill(RED);
                Boxes.alert("Limit Reached", desErr);
            }else{
                workIn.getStyleClass().remove("err");
                SessionWork = st;
            }
           if(!SessionDate.isEmpty() && !SessionVenue.isEmpty() && !SessionWork.isEmpty() && !SessionDuration.isEmpty()){
               
               lec.createSession(stud, SessionTime, SessionDate, SessionDuration, SessionWork, SessionVenue);
           }else{
               Boxes.alert("Creation Error", "Error Creating Session. Check all fields");
               if(dateIn.getValue() == null){
                   window.setScene(scene1);
               }
           }
            System.out.println(finalSessionTime);
           
           
        });
        
        layout1.add(list, 0,0);
        layout1.add(head1, 1, 0);
        layout1.add(form1, 1, 1);
        layout1.add(buttons1, 1,2);
        GridPane.setRowSpan(list, 4);
        
        layout2.add(list2, 0,0);
        layout2.add(head2, 1, 0);
        layout2.add(form2, 1, 1);
        layout2.add(buttons2, 1,2);
        GridPane.setRowSpan(list2, 5);
        
        
        next.setOnAction(e -> window.setScene(scene2));
        previous.setOnAction(e -> window.setScene(scene1));
        
       
        scene1.getStylesheets().add("/COT/SuperviZe/theme.css");
        scene2.getStylesheets().add("/COT/SuperviZe/theme.css");
        window.setScene(scene1);
        window.setResizable(false);
        window.setTitle("SuperviZe | Create Session");
        window.getIcons().add(new Image("/COT/SuperviZe/photos/superviZe.png")); 
        window.show();
        return feedback;
    }
    public static String DateToString(LocalDate date) {
        String pattern = "dd/MM/yyyy";
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(pattern);
         if (date != null) {
             return dateFormatter.format(date);
         } else {
             return "";
         }
     }
}
