/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package COT.SuperviZe;

import java.sql.*;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;

import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

/**
 *
 * @author CARTER
 */
public class SignUp {
    
  
    public static Scene sign() {
        Stage primaryStage = null;
        
        DBConnect conn = new DBConnect();
        GridPane group = new GridPane();
        group.getStyleClass().add("grid");
        ColumnConstraints column1 = new ColumnConstraints();
        column1.setPercentWidth(40);
        ColumnConstraints column2 = new ColumnConstraints();
        column2.setPercentWidth(60);
        group.getColumnConstraints().addAll(column1, column2); // each get 50% of width
        
        group.setHgap(30);
        //group.setVgap(20);
        Image logo = new Image("/COT/SuperviZe/photos/superviZe_logo.png");
        ImageView view = new ImageView(logo);
        view.setFitHeight(200);
        view.setFitWidth(210);
        view.setPreserveRatio(true);
        view.getImage();
        Label welcome = new Label();
        welcome.getStyleClass().add("welcome");
        String quote = " \"Welcome to SuperviZe. SuperviZe is a platform aimed at easing project supervision. SuperviZe looks at "
                + "supervision from the perspective of the supervisors and tries to solve some of those problems faced in supervision. "
                + "We had alot of fun developing the application, hope you have alot of fun using it. "
                + "SignUp to Get Started\" ";
        welcome.setText(quote);
        welcome.setWrapText(true);
        welcome.setTextAlignment(TextAlignment.CENTER);
        Label h1 = new Label("SIGNUP");
        h1.getStyleClass().add("h1");
        h1.setWrapText(true);
        group.setHalignment(h1, HPos.LEFT);
       
       
       
         VBox root = new VBox(8);
         VBox col1 = new VBox(5);
         col1.getChildren().addAll(view, welcome);
          group.add(col1, 0,0);
         root.getStyleClass().add("form");
          col1.getStyleClass().add("greeting");
         
        Label Surname = new Label("Surname");
        Surname.getStyleClass().add("labels");
        
        TextField surnameIn = new TextField();
        Text surnameErrdisplay = new Text("");
       
        Label name = new Label("Name");
        
        TextField nameIn = new TextField();
        Text nameErrdisplay = new Text("");
       
        Label title = new Label("Title");
        
        TextField titleIn = new TextField();
        Text titleErrdisplay = new Text("");
        
        Label username = new Label("Username");
        
        TextField usernameIn = new TextField();
        Text usernameErrdisplay = new Text("");
        
        Label password = new Label("Password");
        
        PasswordField passwordIn = new PasswordField();
        passwordIn.addEventFilter(KeyEvent.KEY_RELEASED, new EventHandler<KeyEvent>(){
		@Override
		public void handle(KeyEvent arg0) {
			PasswordField f=(PasswordField)arg0.getSource();
			int length = f.getText().length();

			if(length < 6){
				removeAllStyle(f);
				f.getStyleClass().add("weak"); 
			}
			else if(length >= 6 && length < 12){
				removeAllStyle(f);
				f.getStyleClass().add("med");
			}
			else if(length >=12){
				removeAllStyle(f);
				f.getStyleClass().add("good");
			}
			else{
				removeAllStyle(f);
			}

		}
	});
        Text pwErrdisplay = new Text("");
       
        Label repassword = new Label("Retype Password");
        
        PasswordField repasswordIn = new PasswordField();
        Text repwErrdisplay = new Text("");
        
        Button signUp = new Button("Create User");
        signUp.getStyleClass().add("btn");
        
        Button Closebtn = new Button();
        Closebtn.setText("X");
        signUp.setOnAction(e -> {
            
            String surnameErr = "";
            String surN = "";
            String Nm = "";
            String tl = "";
            String pw = "";
            String rpw = "";
            String us = "";
            String nameErr = "";
            String titleErr = "";
            String usernameErr = "";
            String passwordErr = "";
            String rePasswordErr = "";
        
            if(surnameIn.getText().trim().isEmpty()){
                surnameErr = "Please input surname";
                 surnameErrdisplay.setText(surnameErr);
                 surnameIn.clear();
                 surnameIn.promptTextProperty().set(surnameErr);
                surnameIn.getStyleClass().add("err");
            }else if(!compareString(surnameIn.getText())){
                surnameErr = "Surname should contain only letters";
                 surnameErrdisplay.setText(surnameErr);
                 surnameIn.clear();
                 surnameIn.promptTextProperty().set(surnameErr);
                surnameIn.getStyleClass().add("err");
            }else{
                surN = surnameIn.getText().trim();
                surnameIn.getStyleClass().removeAll("err");
            }
            
            if(nameIn.getText().trim().isEmpty()){
               nameErr = "Please input name";
               nameErrdisplay.setText(nameErr);
               nameIn.clear();
               nameIn.promptTextProperty().set(nameErr);
                nameIn.getStyleClass().add("err");
            }else if(!compareString(nameIn.getText())){
               nameErr = "Name should contain only letters";
               nameErrdisplay.setText(nameErr);
                nameIn.clear();
               nameIn.promptTextProperty().set(nameErr);
                nameIn.getStyleClass().add("err");
            }else{
                Nm = nameIn.getText().trim();
                nameIn.getStyleClass().removeAll("err");
            }
            
            if(titleIn.getText().trim().isEmpty()){
               titleErr = "Please input your title(e.g Mr, Mrs, Dr, Prof etc)";
                titleErrdisplay.setText(titleErr);
                titleIn.clear();
                titleIn.promptTextProperty().set(titleErr);
                titleIn.getStyleClass().add("err");
            }else if(!compareString(titleIn.getText().trim())){
               titleErr = "Title should contain only letters";
                titleErrdisplay.setText(titleErr);
                titleIn.clear();
                titleIn.promptTextProperty().set(titleErr);
                titleIn.getStyleClass().add("err");
            }else{
                tl = titleIn.getText().trim();
                titleIn.getStyleClass().removeAll("err");
            }
            
            if(usernameIn.getText().trim().isEmpty()){
               usernameErr = "Please input a Username";
                usernameErrdisplay.setText(usernameErr);
                usernameIn.clear();
                usernameIn.promptTextProperty().set(usernameErr);
                usernameIn.getStyleClass().add("err");
            }else if(!compareString(usernameIn.getText())){
              usernameErr = "Username should contain only letters";
               usernameErrdisplay.setText(usernameErr);
                usernameIn.clear();
               usernameIn.promptTextProperty().set(usernameErr);
                usernameIn.getStyleClass().add("err");
            }else{
                us = usernameIn.getText().trim();
                usernameIn.getStyleClass().removeAll("err");
            }
            
            if(passwordIn.getText().trim().isEmpty()){
               passwordErr = "Please input a password";
                pwErrdisplay.setText(passwordErr);
                passwordIn.clear();
                passwordIn.getStyleClass().add("err");
                 passwordIn.promptTextProperty().set(passwordErr);
            }else if(passwordIn.getText().length() < 6){
               passwordErr = "Password should be atleast six characters long";
                pwErrdisplay.setText(passwordErr);
                passwordIn.clear();
                passwordIn.getStyleClass().add("err");
                 passwordIn.promptTextProperty().set(passwordErr);
            }else{
                pw = passwordIn.getText().trim();
                passwordIn.getStyleClass().removeAll("err");
            }
            
            if(repasswordIn.getText().trim().isEmpty()){
               rePasswordErr = "Please retype password";
                repasswordIn.getStyleClass().add("err");
                repasswordIn.clear();
               repwErrdisplay.setText(rePasswordErr);
               repasswordIn.promptTextProperty().set(rePasswordErr);
            }else if(!repasswordIn.getText().equals(passwordIn.getText())){
               rePasswordErr = "Retyped password should be same as password";
                repasswordIn.getStyleClass().add("err");
                repasswordIn.clear();
               repwErrdisplay.setText(rePasswordErr);
               repasswordIn.promptTextProperty().set(rePasswordErr);
            }else{
                rpw = passwordIn.getText().trim();
                repasswordIn.getStyleClass().removeAll("err");
            }
            
            if(surN.isEmpty() || Nm.isEmpty() || tl.isEmpty() || us.isEmpty() || pw.isEmpty() || rpw.isEmpty()){
                
             primaryStage.setScene(Login.login());
                System.out.println("nothing");
              
                
               
                /*
                
                */
                
            }else{
                 System.out.println(surN);
                 System.out.println(Nm);
                 System.out.println(tl);
                 System.out.println(us);
                 System.out.println(pw);
                 
                 Connection c = conn.DBconn();
                try{
                    String sql = "INSERT INTO Lecturer(Lsurname, Lname, Ltitle, Username, Lpassword, Active)"+
                            "VALUES(?,?,?,?,?,?);";
                    PreparedStatement prep = c.prepareStatement(sql);
                    prep.setString(1, surN);
                    prep.setString(2, Nm);
                    prep.setString(3, tl);
                    prep.setString(4, us);
                    prep.setString(5, pw);
                    prep.setInt(6, 1);
                    prep.execute();
           
                    c.close();
                }catch(SQLException ex){
                    System.err.println( ex.getClass().getName() + ": " + ex.getMessage() );
                    System.exit(0);
                }
                System.out.println("new user created");
                
            }
              
        } );
        
       root.getChildren().addAll(Surname, surnameIn, name, nameIn, title, titleIn, username, usernameIn, password, passwordIn, repassword, repasswordIn, signUp);
       group.setHalignment(root, HPos.RIGHT);
       group.add(root, 1,0);
       
        
       
        
        Scene scene = new Scene(group, 480, 400);
         primaryStage.setResizable(false);
        scene.getStylesheets().add("/COT/SuperviZe/theme.css");
        primaryStage.setTitle("SuperviZe | SignUp");
        primaryStage.getIcons().add(new Image("/COT/SuperviZe/photos/superviZe.png")); 
        primaryStage.setScene(scene);
        primaryStage.show();
        
        return scene;
    }
    
    public static boolean compareString(String s){      
     String regex="[A-Za-z\\s]+";      
      return s.matches(regex);//returns true if input and regex matches otherwise false;
 }
    public static void removeAllStyle(Node n){

	    n.getStyleClass().removeAll("weak","med","good");

	}
}
