/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package COT.SuperviZe;

import java.util.Calendar;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author CARTER
 */
public class NewYear {
    public static boolean feedback;
    public static boolean createYear(){
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        GridPane layout = new GridPane();
        layout.setHgap(30);
        ColumnConstraints column1 = new ColumnConstraints();
        column1.setPercentWidth(40);
        ColumnConstraints column2 = new ColumnConstraints();
        column2.setPercentWidth(60);
        layout.getColumnConstraints().addAll(column1, column2);
        
        //The form
        Label heading = new Label("Choose Academic Year");
        Separator sep = new Separator();
        Label year = new Label("Select Year");
        Button cancel = new Button("Cancel");
        cancel.setOnAction(e -> window.close());
        cancel.setMinWidth(80);
        cancel.getStyleClass().add("btn");
        Button create = new Button("Create");
        create.setMinWidth(80);
        create.getStyleClass().add("btn");
        ChoiceBox<String> yearIn = new ChoiceBox<String>();
        Calendar now= Calendar.getInstance();//Gets System time
        int currentYear = now.get(Calendar.YEAR);//Gets the year potion of system time
        
        for (int i = 0; i < 5; i++) {
            System.out.println(currentYear + i + "/" + (currentYear + i + 1) );
            yearIn.getItems().add(currentYear + i + "/" + (currentYear + i + 1));   
        }
        yearIn.setValue(currentYear + "/" + (currentYear + 1));
        
        //creating secodary layouts
        VBox head = new VBox(20);
        head.getStyleClass().add("head");
        head.getChildren().addAll(heading, sep);
        
        VBox form = new VBox(12);
        form.getStyleClass().add("addForm");
        form.getChildren().addAll(year, yearIn);
        
        VBox list = new VBox(10);
        list.getStyleClass().add("list");
        
        HBox buttons = new HBox(78);
        buttons.getStyleClass().add("addForm");
        buttons.getChildren().addAll(cancel, create);
        
        //adding elements to primary layout
        layout.add(list, 0, 0);
        layout.add(head, 1, 0);
        layout.add(form, 1, 1);
        layout.add(buttons, 1, 2);
        GridPane.setRowSpan(list, 3);
        
        create.setOnAction(e -> {
            Lecturer lec = new Lecturer("Sidney", "Ndula", 1);
            lec.createYear(yearIn.getValue().trim());
        });
        
        Scene scene = new Scene(layout, 500, 210);
        scene.getStylesheets().add("/COT/SuperviZe/theme.css");
        window.setScene(scene);
        window.setTitle("SuperviZe | Create Year");
        window.getIcons().add(new Image("/COT/SuperviZe/photos/superviZe.png")); 
        window.setResizable(false);
        window.show();
        return feedback;
    }
}
