/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package COT.SuperviZe;

import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author CARTER
 */
public class Search {
   static ArrayList<String> nameList = new ArrayList<>();
   static DBConnect conn = new DBConnect();
    public static ArrayList<String> searchIt(String year, String name){
        Connection c = conn.DBconn();
        String[] nameSplit = name.toUpperCase().split(" ");
        int nameSplitLength = nameSplit.length;
        
        try{
            String sql = "SELECT Sname, StudID FROM Student WHERE year = ?";
            PreparedStatement prep = c.prepareStatement(sql);
            prep.setString(1, year);
            ResultSet rs = prep.executeQuery();
            while(rs.next()){
                String[] dbNameSplit = rs.getString("Sname").toUpperCase().split(" ");
                int dbNameSplitLength = dbNameSplit.length;
                for (int i = 0; i < nameSplitLength; i++) {
                    for (int j = 0; j < dbNameSplitLength; j++) {
                        if(nameSplit[i].equals(dbNameSplit[j])){
                           if(!nameList.contains(rs.getString("Sname") + "     " + rs.getString("StudID"))){
                                nameList.add(rs.getString("Sname") + "     " + rs.getString("StudID"));
                           }
                           
                        }  
                    }
                }
            }
            prep.close();
            rs.close();
            c.close();
            
        }catch(SQLException e){
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
        
        return nameList;
    }
    
}
